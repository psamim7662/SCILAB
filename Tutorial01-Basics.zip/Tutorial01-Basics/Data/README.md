# Data for matrix manipulation
