//This function is to import data from a csv file and store it in a variable
//Using the data mean and standard deviation of the data is computed
clear


exec('/home/samim/scilab-tutorials-master/Tutorial01-Basics/Scilab_code/mymean.sci');
exec('/home/samim/scilab-tutorials-master/Tutorial01-Basics/Scilab_code/mystdev.sci');


//Import data from csv file
Data = csvRead('/home/samim/scilab-tutorials-master/Tutorial01-Basics/Data/Tut1_data1.csv');
x = Data(:,1);
y = Data(:,2);


//Compute mean of the imported data
mean_of_x = mymean(x);
mean_of_y = mymean(y);
//Compute standard deviation of the imported data
stdev_of_x= mystdev(x,mean_of_x);

//Data to be exported (It can be a scalar, vector or matrix)
//data_to_write = [mean_of_x stdev_of_x];

//Compute standard deviation of the imported data
stdev_of_y= mystdev(y,mean_of_y);

//Data to be exported (It can be a scalar, vector or matrix)
data_to_write = [mean_of_x stdev_of_x;mean_of_y stdev_of_y];
//Export data to a csv file
csvWrite(data_to_write,'/home/samim/scilab-tutorials-master/Tutorial01-Basics/Data/Result.csv')


