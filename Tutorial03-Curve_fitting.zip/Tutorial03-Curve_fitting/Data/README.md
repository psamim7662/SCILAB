# Data for curve fitting
