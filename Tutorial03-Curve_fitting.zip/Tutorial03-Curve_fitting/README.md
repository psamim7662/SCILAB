# Curve fitting
