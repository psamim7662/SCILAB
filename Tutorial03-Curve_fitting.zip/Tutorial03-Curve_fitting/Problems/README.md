# Problems for curve fitting
